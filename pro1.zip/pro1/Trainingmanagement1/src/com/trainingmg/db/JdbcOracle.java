package com.trainingmg.db;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class JdbcOracle {
	String url="jdbc:oracle:thin:@localhost:1521:orcl";
	String dbUser="system";
	String dbpwd="Yas#1234";
	private static JdbcOracle jdbcconn=null;
	private JdbcOracle()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(ClassNotFoundException e)
		{e.printStackTrace();}
	}
	
		public Connection getConnection() throws SQLException{
			
			
			Connection conn=null;
			conn=DriverManager.getConnection(url,dbUser,dbpwd);
			return conn;
		}
		public static JdbcOracle getInstance() {
			if(jdbcconn==null) {
				jdbcconn=new JdbcOracle();
		}
		return jdbcconn;
		}
}