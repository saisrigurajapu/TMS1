package com.vir.service;

import java.util.List;

import com.vir.model.Training;

public interface TrainingService {
	
	TrainingService findById(Training tng);
	TrainingService findAll(Training tng);
	TrainingService add(Training tng);
	TrainingService update(Training tng);
	TrainingService remove(Training tng);
	/*
	Training findById(int tngid);
	List<Training> findAll();
	Training add(Training tng);
	Training update( Training tng);
	Training remove(Training tng);
*/
}
