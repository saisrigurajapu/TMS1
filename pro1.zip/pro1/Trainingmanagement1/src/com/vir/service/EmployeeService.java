package com.vir.service;

import java.util.List;

import com.vir.model.Employee;

public interface EmployeeService {
	Employee findById(int empid);
	List<Employee> findAll();
	Employee addEmployeeServ(Employee emp);
	Employee updateEmployeeServ( Employee emp);
	Employee removeEmployeeServ(Employee emp);
	int validateEmpUser(Employee emp);
	int validatePmUser(Employee emp);
	int validateAdminUser(Employee emp);

}
