package com.vir.model;

public class Nomination {
	private int noId,tngId,feedBackPts;
	private String appStatus,appDate,description;
	public Nomination(int noId, int tngId, int feedBackPts, String appStatus, String appDate, String description) {
		super();
		this.noId = noId;
		this.tngId = tngId;
		this.feedBackPts = feedBackPts;
		this.appStatus = appStatus;
		this.appDate = appDate;
		this.description = description;
	}
	public int getNoId() {
		return noId;
	}
	public void setNoId(int noId) {
		this.noId = noId;
	}
	public int getTngId() {
		return tngId;
	}
	public void setTngId(int tngId) {
		this.tngId = tngId;
	}
	public int getFeedBackPts() {
		return feedBackPts;
	}
	public void setFeedBackPts(int feedBackPts) {
		this.feedBackPts = feedBackPts;
	}
	public String getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}
	public String getAppDate() {
		return appDate;
	}
	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	

}
