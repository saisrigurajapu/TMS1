package com.vir.model;

public class Employee {
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", pmId=" + pmId + ", empName=" + empName + ", passCode=" + passCode
				+ ", empType=" + empType + ", empEmail=" + empEmail + "]";
	}
	private int empId,pmId;
	private String empName,passCode,empType,empEmail;
	
	private String 
	public Employee(int empId, int pmId, String empName, String passCode, String empType,String empEmail) {
		super();
		this.empId = empId;
		this.pmId = pmId;
		this.empName = empName;
		this.passCode = passCode;
		this.empType = empType;
		this.empEmail = empEmail;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getPmId() {
		return pmId;
	}
	public void setPmId(int pmId) {
		this.pmId = pmId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getPassCode() {
		return passCode;
	}
	public void setPassCode(String passCode) {
		this.passCode = passCode;
	}
	public String getEmpType() {
		return empType;
	}
	public void setEmpType(String empType) {
		this.empType = empType;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String passCode,String empType) {
		super();
		this.empId = empId;
		this.passCode = passCode;
		this.empType = empType;
	}
}
