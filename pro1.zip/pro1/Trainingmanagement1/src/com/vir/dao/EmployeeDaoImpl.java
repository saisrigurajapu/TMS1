package com.vir.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vir.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	Logger log=Logger.getRootLogger();
	Connection connection = null;
	PreparedStatement ps = null;
	ResultSet rs=null;

	private Connection getConnection() throws SQLException {
		Connection conn;
		conn = com.trainingmg.db.JdbcOracle.getInstance().getConnection() ;
		return conn;
	}

	
	@Override
	public Employee addEmployee(Employee emp) {
		try {
			String query = "insert into employee values(?,?,?,?,?,?)";
			connection = getConnection();
			ps = connection.prepareStatement(query);
			ps.setLong(1, emp.getEmpId());
			ps.setString(2, emp.getEmpName());
			ps.setLong(3, emp.getPmId());
			ps.setString(4, emp.getPassCode());
			ps.setString(5, emp.getEmpType());
			ps.setString(6, emp.getEmpEmail());
			ps.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			log.trace(e);
		}
		return emp;

	}

	@Override
	public Employee updateEmployee(Employee emp) {
		try {
			String query = "update employee set empname=?,pmid=?,passcode=?,empType=?,Email=? where empid=?";
			connection = getConnection();
			ps = connection.prepareStatement(query);
			
			ps.setString(1, emp.getEmpName());
			ps.setLong(2, emp.getPmId());
			ps.setString(3, emp.getPassCode());
			ps.setString(4, emp.getEmpType());
			ps.setString(5, emp.getEmpEmail());
			ps.setLong(6, emp.getEmpId());
			ps.executeUpdate();
			connection.commit();
			log.trace("updated employee");
		} catch (SQLException e) {
			log.trace(e);
		}
		
		return emp;
	}

	@Override
	public Employee removeEmployee(int empid) {
		Employee emp=new Employee();
		try {
			String query = "delete from employee where empid=?";
	         connection = getConnection();
	        ps = connection.prepareStatement(query);
			ps.setLong(1, emp.getEmpId());
			emp = findById(empid);
			ps.executeUpdate();
			log.trace("removed employee");
			return emp;
		} catch (SQLException e) {
			log.trace(e);
			return null;
		}
	}
	

	@Override
	public List<Employee> findAll() {
		List<Employee> list = new ArrayList<>();
		Employee e = null;
		try {
			String query = "select * from employee";
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				int i = rs.getInt(1);
				String ename = rs.getString(2);
				int pmid = rs.getInt(3);
				String pass = rs.getString(4);
				String empType = rs.getString(5);
				String email = rs.getString(6);
				e = new Employee(i, pmid, ename, pass, empType, email);
				list.add(e);
			}
			return list;
		} catch (SQLException ex) {
			log.trace(ex);
		}
		return list;

	}


	@Override
	public Employee findById(int eid) {
		Employee e = null;
		try {
			String query = "select * from employee where empid = " + eid;
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				int i = rs.getInt(1);
				String ename = rs.getString(2);
				int pmid = rs.getInt(3);
				String pass = rs.getString(4);
				String empType = rs.getString(5);
				String email = rs.getString(6);
				e = new Employee(i, pmid, ename, pass, empType, email);
				return e;
			}
		} catch (SQLException ex) {
			log.trace(ex);
			return null;
		}
		return null;
	}

}
