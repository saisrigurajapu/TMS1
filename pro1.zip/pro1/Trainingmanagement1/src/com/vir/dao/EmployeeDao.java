package com.vir.dao;
import java.util.List;
import com.vir.model.Employee;

public interface EmployeeDao {
		Employee findById(int eid);
	List<Employee> findAll();
	Employee addEmployee(Employee emp);
	Employee updateEmployee(Employee emp);
	public Employee removeEmployee(int empid);
}
