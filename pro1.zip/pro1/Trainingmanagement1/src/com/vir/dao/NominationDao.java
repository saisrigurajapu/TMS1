package com.vir.dao;

import java.util.List;

import com.vir.model.Nomination;

public interface NominationDao {
	Nomination findById(int noid);
	List<Nomination> findAll();
	Nomination add(Nomination no);
	Nomination update( Nomination no);
	Nomination remove(Nomination no);

}
