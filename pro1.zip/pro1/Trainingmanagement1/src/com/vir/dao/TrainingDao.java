package com.vir.dao;

import java.util.List;

import com.vir.model.Training;

public interface TrainingDao {
	Training findById(int tngid);
	List<Training> findAll();
	Training add(Training tng);
	Training update( Training tng);
	Training remove(Training tng);

}
