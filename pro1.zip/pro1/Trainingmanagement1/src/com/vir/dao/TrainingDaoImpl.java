package com.vir.dao;

import java.util.List;
import org.apache.log4j.Logger;

import com.vir.model.Training;

public class TrainingDaoImpl implements TrainingDao{
	Logger log=Logger.getRootLogger();
	@Override
	public Training findById(int tngid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Training> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Training add(Training tng) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Training update(Training tng) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Training remove(Training tng) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
