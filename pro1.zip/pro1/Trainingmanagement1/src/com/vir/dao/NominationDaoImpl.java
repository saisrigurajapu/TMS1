package com.vir.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.vir.model.Nomination;

public class NominationDaoImpl implements NominationDao {
	Logger log=Logger.getRootLogger();
	@Override
	public Nomination findById(int noid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Nomination> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Nomination add(Nomination no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Nomination update(Nomination no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Nomination remove(Nomination no) {
		// TODO Auto-generated method stub
		return null;
	}

}
